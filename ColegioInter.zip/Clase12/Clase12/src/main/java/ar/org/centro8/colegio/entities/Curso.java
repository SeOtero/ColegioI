package ar.org.centro8.colegio.entities;



import ar.org.centro8.colegio.enums.Dia;
import ar.org.centro8.colegio.enums.Turno;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table (name="Curso")
    public class Curso {
        @Id
        private Integer id;
        private String titulo;
        private String profesor;
        @Enumerated
        private Dia dia;
        private Turno turno;

        public Curso() {
        }

        public Curso(String titulo, String profesor, Dia dia, Turno turno) {
            this.titulo = titulo;
            this.profesor = profesor;
            this.dia = dia;
            this.turno = turno;
        }

        public Curso(Integer id, String titulo, String profesor, Dia dia, Turno turno) {
            this.id = id;
            this.titulo = titulo;
            this.profesor = profesor;
            this.dia = dia;
            this.turno = turno;
        }

       

        
}

