package ar.org.centro8.colegio.repositories;

import org.springframework.data.repository.CrudRepository;

import ar.org.centro8.colegio.entities.Alumno;


public interface AlumnoRepository 
            extends CrudRepository<Alumno, Integer> {
    
} 