package ar.org.centro8.colegio.repositories;

import org.springframework.data.repository.CrudRepository;

import ar.org.centro8.colegio.entities.Curso;

public interface CursoRepository 
            extends CrudRepository<Curso, Integer> {
    
}