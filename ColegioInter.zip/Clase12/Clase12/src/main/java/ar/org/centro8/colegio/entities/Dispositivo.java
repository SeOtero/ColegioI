package ar.org.centro8.colegio.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="dispositivos")
public class Dispositivo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private Integer id;
    private String fecha;
    private String hora;
    private String ip_privada;
    private String ip_publica;
    private String nombre;
    //@Column(name="cursos")
    private String curso;
    private String turno;
    private String aula;
    private String bien;
    private String marca;
    //@Transient
    private String observaciones;
    
    public Dispositivo() {
    }

    public Dispositivo(String fecha, String hora, String ip_privada, String ip_publica, String nombre, String curso,
            String turno, String aula, String bien, String marca, String observaciones) {
        this.fecha = fecha;
        this.hora = hora;
        this.ip_privada = ip_privada;
        this.ip_publica = ip_publica;
        this.nombre = nombre;
        this.curso = curso;
        this.turno = turno;
        this.aula = aula;
        this.bien = bien;
        this.marca = marca;
        this.observaciones = observaciones;
    }

    public Dispositivo(Integer id, String fecha, String hora, String ip_privada, String ip_publica, String nombre,
            String curso, String turno, String aula, String bien, String marca, String observaciones) {
        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.ip_privada = ip_privada;
        this.ip_publica = ip_publica;
        this.nombre = nombre;
        this.curso = curso;
        this.turno = turno;
        this.aula = aula;
        this.bien = bien;
        this.marca = marca;
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "Dispositivo [id=" + id + ", fecha=" + fecha + ", hora=" + hora + ", ip_privada=" + ip_privada
                + ", ip_publica=" + ip_publica + ", nombre=" + nombre + ", curso=" + curso + ", turno=" + turno
                + ", aula=" + aula + ", bien=" + bien + ", marca=" + marca + ", observaciones=" + observaciones + "]";
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getIp_privada() {
        return ip_privada;
    }

    public void setIp_privada(String ip_privada) {
        this.ip_privada = ip_privada;
    }

    public String getIp_publica() {
        return ip_publica;
    }

    public void setIp_publica(String ip_publica) {
        this.ip_publica = ip_publica;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getAula() {
        return aula;
    }

    public void setAula(String aula) {
        this.aula = aula;
    }

    public String getBien() {
        return bien;
    }

    public void setBien(String bien) {
        this.bien = bien;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

}
